﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FinalPart1
{
    [TestClass]
    public class UnitTest1
    {
        public bool CanDrive(int age)
        {
            const int drivingAge = 16; return age >= drivingAge;
        }



        // Min Number Age 0 Tests
        [TestMethod]
        public void TestMethod1() { Assert.IsFalse(CanDrive(-1)); }
        // Min Number 
        [TestMethod]
        public void TestMethod2() { Assert.IsFalse(CanDrive(0)); }
        // Min Number +1
        [TestMethod]
        public void TestMethod3() { Assert.IsFalse(CanDrive(1)); }

        // Max Value  Upper Bound
        [TestMethod]
        public void TestMethod4() { Assert.IsTrue(CanDrive(int.MaxValue)); }
        // Max Value - 1
        [TestMethod]
        public void TestMethod5() { Assert.IsTrue(CanDrive(int.MaxValue - 1)); }

        // Min Integer Tests
        [TestMethod]
        public void TestMethod6() { Assert.IsFalse(CanDrive(int.MinValue)); }
        [TestMethod]
        public void TestMethod7() { Assert.IsFalse(CanDrive(int.MinValue + 1)); }

        // Lower Bound
        [TestMethod]
        public void TestMethod8() { Assert.IsFalse(CanDrive(15)); }
        [TestMethod]
        public void TestMethod9() { Assert.IsTrue(CanDrive(16)); }
        [TestMethod]
        public void TestMethod10() { Assert.IsTrue(CanDrive(17)); }

    }
}
